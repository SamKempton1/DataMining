import pandas as pd

# split_data function can be used later before run modeling
def split_data(df, train_timestamp):
    # you can change the train_timestamp to include more training
    test_start, test_end = pd.Timestamp(2021, 2, 15), pd.Timestamp(2021, 3, 1)
    train_start = train_timestamp  
    df['Sold On'] = pd.to_datetime(df['Sold On'], errors='coerce')
    train = df[(df['Sold On'] >= train_start) & (df['Sold On'] < test_start)]
    test = df[(df['Sold On'] >= test_start) & (df['Sold On'] < test_end)]
    return train, test

# the following sample code include only 2021 data for training 
#train, test = split_data(df1, pd.Timestamp(2021, 1, 1))
#train.shape, test.shape