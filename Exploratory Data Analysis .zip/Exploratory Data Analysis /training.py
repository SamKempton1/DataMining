
def prepare_train_test(train, test, features):
    target = "Sold Price"
    X_train = train.loc[:, features ]
    y_train = train.loc[:, [target]]
    X_test = test.loc[:, features]
    y_test = test.loc[:, [target]]
    return X_train, y_train, X_test, y_test
