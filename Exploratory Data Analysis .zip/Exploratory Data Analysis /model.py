# if the packages are not installed, install them using 
import sklearn
# import lightgbm


#from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GridSearchCV

import lightgbm as lgb

# define modeling function can be used later
def modeling (x_train, y_train, x_test, y_test):
    from sklearn.metrics import mean_squared_error
    print('Starting training...')
    # train
    gbm = lgb.LGBMRegressor(num_leaves=31,
                        learning_rate=0.05,
                        n_estimators=100)
    gbm.fit(x_train, y_train,
        eval_set=[(x_test, y_test)],
        eval_metric='l2',
        callbacks=[lgb.early_stopping(5)])

    print('Starting predicting...')
    # predict
    y_pred = gbm.predict(x_test, num_iteration=gbm.best_iteration_)
    # eval
    # use root mean squared error (RMSE)
    rmse_test = mean_squared_error(y_test, y_pred) ** 0.5
    print(f'The RMSE of prediction is: {rmse_test}')
    return gbm
